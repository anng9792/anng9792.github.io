# CSS Holographic Masks

A Pen created on CodePen.

Original URL: [https://codepen.io/HejChristian/pen/YPzLbYX](https://codepen.io/HejChristian/pen/YPzLbYX).

Experimenting with some CSS holographic effects, inspired by this guide from Robb Owen: https://robbowen.digital/wrote-about/css-blend-mode-shaders/