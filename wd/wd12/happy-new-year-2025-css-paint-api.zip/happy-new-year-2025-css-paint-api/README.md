# Happy New Year 2025 — CSS Paint API

A Pen created on CodePen.

Original URL: [https://codepen.io/hexagoncircle/pen/ogvoXpx](https://codepen.io/hexagoncircle/pen/ogvoXpx).

A "glitter gifs" style experiment for the new year 